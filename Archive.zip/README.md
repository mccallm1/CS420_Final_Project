# CS420_Final_Project
Description of folders:

  Final - Contains Java project with nearest neighbor + simulated annealing algorithm

    to run Java code:

      java -jar  out/artifacts/test_jar/test.jar src/simulated/annealing/data/test-input-1.txt

  NN - Contains C++ project with nearest neighbor + 2-opt Algorithm
